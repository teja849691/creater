import { useState, useEffect } from 'react';
import { unified } from 'unified';
import remarkParse from 'remark-parse';
import remarkGfm from 'remark-gfm';
import remarkRehype from 'remark-rehype';
import rehypeHighlight from 'rehype-highlight';
import rehypeStringify from 'rehype-stringify';

const themes = {
  minimal: {
    name: 'Minimal',
    class: 'bg-white text-gray-900',
    preview: 'bg-white border-gray-200',
    accent: 'text-blue-600',
    accentHex: '#2563eb'
  },
  dark: {
    name: 'Dark Professional',
    class: 'bg-gray-900 text-gray-100',
    preview: 'bg-gray-800 border-gray-700 text-gray-100',
    accent: 'text-blue-400',
    accentHex: '#60a5fa'
  },
  modern: {
    name: 'Modern Blue',
    class: 'bg-gradient-to-br from-blue-50 to-indigo-100 text-gray-900',
    preview: 'bg-white border-blue-200',
    accent: 'text-indigo-600',
    accentHex: '#4f46e5'
  },
  creative: {
    name: 'Creative Purple',
    class: 'bg-gradient-to-br from-purple-50 to-pink-50 text-gray-900',
    preview: 'bg-white border-purple-200',
    accent: 'text-purple-600',
    accentHex: '#7c3aed'
  },
  nature: {
    name: 'Nature Green',
    class: 'bg-gradient-to-br from-green-50 to-emerald-50 text-gray-900',
    preview: 'bg-white border-green-200',
    accent: 'text-emerald-600',
    accentHex: '#059669'
  }
};

const sampleMarkdown = `# John Doe
## Full Stack Developer

### About Me
I'm a passionate full stack developer with 5+ years of experience building modern web applications. I love creating efficient, scalable solutions and learning new technologies.

### Skills
- **Frontend:** React, Vue.js, TypeScript, Tailwind CSS
- **Backend:** Node.js, Python, PostgreSQL, MongoDB
- **DevOps:** Docker, AWS, CI/CD, Kubernetes
- **Tools:** Git, VS Code, Figma, Postman

### Experience

#### Senior Developer at TechCorp (2022 - Present)
- Led development of microservices architecture serving 1M+ users
- Implemented CI/CD pipelines reducing deployment time by 60%
- Mentored junior developers and conducted code reviews

#### Full Stack Developer at StartupXYZ (2020 - 2022)
- Built responsive web applications using React and Node.js
- Optimized database queries improving performance by 40%
- Collaborated with design team to implement pixel-perfect UIs

### Projects

#### E-commerce Platform
A full-featured e-commerce solution with payment integration, inventory management, and admin dashboard.
- **Tech Stack:** React, Node.js, PostgreSQL, Stripe API
- **Features:** Real-time inventory, order tracking, analytics
- [Live Demo](https://example.com) | [GitHub](https://github.com)

#### Task Management App
A collaborative task management application with real-time updates and team collaboration features.
- **Tech Stack:** Vue.js, Express, MongoDB, Socket.io
- **Features:** Real-time collaboration, file sharing, notifications
- [Live Demo](https://example.com) | [GitHub](https://github.com)

### Education
**Bachelor of Computer Science**  
University of Technology (2016 - 2020)

### Contact
- **Email:** john.doe@email.com
- **LinkedIn:** [linkedin.com/in/johndoe](https://linkedin.com/in/johndoe)
- **GitHub:** [github.com/johndoe](https://github.com/johndoe)
- **Portfolio:** [johndoe.dev](https://johndoe.dev)`;

export default function MarkdownPortfolioGenerator() {
  const [markdown, setMarkdown] = useState(sampleMarkdown);
  const [html, setHtml] = useState('');
  const [theme, setTheme] = useState('minimal');
  const [isLoading, setIsLoading] = useState(false);
  const [showPreview, setShowPreview] = useState(true);

  const convertMarkdown = async (text) => {
    setIsLoading(true);
    try {
      const file = await unified()
        .use(remarkParse)
        .use(remarkGfm)
        .use(remarkRehype)
        .use(rehypeHighlight)
        .use(rehypeStringify)
        .process(text);
      setHtml(String(file));
    } catch (error) {
      console.error('Error converting markdown:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    convertMarkdown(markdown);
  }, [markdown]);

  const handleMarkdownChange = (e) => {
    setMarkdown(e.target.value);
  };

  const downloadHTML = () => {
    const fullHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github.min.css">
    <style>
        body { font-family: 'Inter', system-ui, sans-serif; }
        .portfolio-content { max-width: 4xl; margin: 0 auto; padding: 2rem; }
        .portfolio-content h1 { font-size: 3rem; font-weight: 700; margin-bottom: 0.5rem; }
        .portfolio-content h2 { font-size: 2rem; font-weight: 600; margin: 2rem 0 1rem 0; color: ${themes[theme].accentHex}; }
        .portfolio-content h3 { font-size: 1.5rem; font-weight: 600; margin: 1.5rem 0 1rem 0; }
        .portfolio-content h4 { font-size: 1.25rem; font-weight: 600; margin: 1rem 0 0.5rem 0; }
        .portfolio-content p { margin-bottom: 1rem; line-height: 1.7; }
        .portfolio-content ul, .portfolio-content ol { margin-bottom: 1rem; padding-left: 1.5rem; }
        .portfolio-content li { margin-bottom: 0.5rem; line-height: 1.6; }
        .portfolio-content strong { font-weight: 600; }
        .portfolio-content a { color: ${themes[theme].accentHex}; text-decoration: underline; }
        .portfolio-content a:hover { opacity: 0.8; }
        .portfolio-content code { background: #f3f4f6; padding: 0.25rem 0.5rem; border-radius: 0.25rem; font-family: 'JetBrains Mono', monospace; }
        .portfolio-content pre { background: #f8f9fa; padding: 1rem; border-radius: 0.5rem; overflow-x: auto; margin: 1rem 0; }
        .portfolio-content blockquote { border-left: 4px solid ${themes[theme].accentHex}; padding-left: 1rem; margin: 1rem 0; font-style: italic; }
    </style>
</head>
<body class="${themes[theme].class}">
    <div class="portfolio-content">
        ${html}
    </div>
</body>
</html>`;

    const blob = new Blob([fullHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'portfolio.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(html);
  };

  return (
    <div className={`min-h-screen transition-all duration-500 ${themes[theme].class}`}>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8 animate-fade-in">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Portfolio Generator
          </h1>
          <p className="text-lg opacity-80 max-w-2xl mx-auto">
            Transform your Markdown resume into a beautiful, professional portfolio website
          </p>
        </div>

        {/* Controls */}
        <div className="flex flex-col md:flex-row gap-4 mb-6 animate-slide-up">
          <div className="flex-1">
            <label className="block text-sm font-medium mb-2">Choose Theme:</label>
            <select 
              value={theme} 
              onChange={(e) => setTheme(e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-gray-300 bg-white text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            >
              {Object.entries(themes).map(([key, themeData]) => (
                <option key={key} value={key}>{themeData.name}</option>
              ))}
            </select>
          </div>
          
          <div className="flex gap-2">
            <button
              onClick={() => setShowPreview(!showPreview)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
            >
              {showPreview ? 'Hide Preview' : 'Show Preview'}
            </button>
            <button
              onClick={downloadHTML}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
            >
              Download HTML
            </button>
            <button
              onClick={copyToClipboard}
              className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium"
            >
              Copy HTML
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className={`grid ${showPreview ? 'md:grid-cols-2' : 'grid-cols-1'} gap-6 animate-slide-up`}>
          {/* Markdown Editor */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Markdown Editor</h2>
              <button
                onClick={() => setMarkdown(sampleMarkdown)}
                className="text-sm px-3 py-1 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition-colors"
              >
                Load Sample
              </button>
            </div>
            <textarea
              className="w-full h-96 p-4 border border-gray-300 rounded-lg font-mono text-sm resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all bg-white text-gray-900"
              placeholder="# Your Name&#10;## Your Title&#10;&#10;### About Me&#10;Write your professional summary here...&#10;&#10;### Skills&#10;- Skill 1&#10;- Skill 2&#10;&#10;### Experience&#10;#### Job Title at Company&#10;Description of your role and achievements..."
              value={markdown}
              onChange={handleMarkdownChange}
            />
          </div>

          {/* Preview */}
          {showPreview && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">Live Preview</h2>
                {isLoading && (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-sm">Converting...</span>
                  </div>
                )}
              </div>
              <div 
                className={`h-96 p-6 border rounded-lg overflow-auto transition-all ${themes[theme].preview} portfolio-preview`}
                style={{ '--accent-color': themes[theme].accentHex }}
                dangerouslySetInnerHTML={{ __html: html }}
              />
            </div>
          )}
        </div>

        {/* Features */}
        <div className="mt-12 grid md:grid-cols-3 gap-6 animate-fade-in">
          <div className="text-center p-6 rounded-lg bg-white/10 backdrop-blur-sm">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h3 className="font-semibold mb-2">Real-time Preview</h3>
            <p className="text-sm opacity-80">See your changes instantly as you type</p>
          </div>
          
          <div className="text-center p-6 rounded-lg bg-white/10 backdrop-blur-sm">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zM21 5a2 2 0 00-2-2h-4a2 2 0 00-2 2v12a4 4 0 004 4h4a2 2 0 002-2V5z" />
              </svg>
            </div>
            <h3 className="font-semibold mb-2">Multiple Themes</h3>
            <p className="text-sm opacity-80">Choose from professional design themes</p>
          </div>
          
          <div className="text-center p-6 rounded-lg bg-white/10 backdrop-blur-sm">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <h3 className="font-semibold mb-2">Export Ready</h3>
            <p className="text-sm opacity-80">Download as HTML or copy to clipboard</p>
          </div>
        </div>
      </div>
    </div>
  );
}